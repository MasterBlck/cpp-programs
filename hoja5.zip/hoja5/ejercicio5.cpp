#include <stdio.h>

int contarVocales(char *frase);


int main(){
	
	return 0;
}
